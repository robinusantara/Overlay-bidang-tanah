<?php
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
const TOKEN = '@Admin2026';   // password admin

$dir = __DIR__ . '/data';
if (!is_dir($dir)) mkdir($dir, 0755, true);

$k = $_GET['k'] ?? '';
if (!in_array($k, ['bpn', 'hutan', 'rtrw'], true)) {
  http_response_code(400); echo '{"error":"layer tidak dikenal"}'; exit;
}
$f = "$dir/$k.json";

// Baca: terbuka untuk semua perangkat
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
  if (is_file($f)) readfile($f); else echo 'null';
  exit;
}

// Tulis/hapus: wajib password
$tok = $_SERVER['HTTP_X_TOKEN'] ?? '';
if (!hash_equals(TOKEN, $tok)) {
  http_response_code(401); echo '{"error":"password salah"}'; exit;
}
if (isset($_GET['del'])) {
  if (is_file($f)) unlink($f);
  echo '{"ok":true}'; exit;
}
$body = file_get_contents('php://input');
$j = json_decode($body, true);
if (!is_array($j) || !isset($j['features'])) {
  http_response_code(400); echo '{"error":"format tidak valid"}'; exit;
}
file_put_contents($f, $body, LOCK_EX);
echo '{"ok":true}';